package com.uk.nationaltrustviewer.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = Login.class.getSimpleName();

    private Button btnLogin;
    private EditText txtUser;
    private EditText txtPass;
    private ProgressDialog pDialog;
    private SessionManager session;
    public static DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        session = new SessionManager(getApplicationContext());
        txtUser = findViewById(R.id.txtUsername);
        txtPass = findViewById(R.id.txtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        db = new DatabaseHandler(this);

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        btnLogin.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
            String code = txtUser.getText().toString();
            if (code.trim().length() > 0) {
                checkLogin(txtUser.getText().toString(), txtPass.getText().toString());
            } else {
                showError("Required", "Please enter valid username and password!");
            }
            }

        });

    }
    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub

        super.onDestroy();
    }

    public void showRegister(View view){
        Intent intent = new Intent(Login.this, Register.class);
        startActivity(intent);
    }
    public void showForgotPass(View view){
        Intent intent = new Intent(Login.this, ForgotPassword.class);
        startActivity(intent);
    }

    private void checkLogin(final String username, final String password) {

        String tag_string_req = "req_login";

        pDialog.setMessage("Signing in ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_LOGIN, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Login Response: " + response);
                hideDialog();

                try {
                    if(response.contains("@Error:")){
                        showError("Login Failed", response.replace("@Error: ", ""));
                    }else{

                        JSONObject res = new JSONObject(response);
                        String table = "members";
                        JSONArray p = res.getJSONArray(table);

                        String id = p.getJSONObject(0).getString("id");
                        String name = p.getJSONObject(0).getString("name");

                        String email = p.getJSONObject(0).getString("email");
                        String password = p.getJSONObject(0).getString("password");

                        session.setV("ACCOUNT_ID", id);
                        session.setV("ACCOUNT_USERNAME", username);
                        session.setV("ACCOUNT_NAME", name);
                        session.setV("ACCOUNT_PASSWORD", password);

                        if(DEBUG){ Log.e("ACCOUNT_USER_ID", id); }
                        createDatabase(db.getWritableDatabase());
                    }

                } catch (JSONException e) {
                    Log.e("JSON_ERROR", "Login Error: " + e.getMessage());
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                showError("Login Failed!", "Please check your internet connection!");
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<>();
                try{
                    params.put("username", username);
                    params.put("password", password);
                    params.put("API_KEY", AppConfig.API_KEY);
                } catch (Exception ex){}
                return params;
            }

        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void createDatabase(final SQLiteDatabase db) {
        String tag_req = "createDatabase";
        pDialog.setMessage("Loading ...");
        showDialog();
        StringRequest srq = new StringRequest(Request.Method.POST, AppConfig.URL_CREATE_DB, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Response: " + response);
                hideDialog();

                Log.d(TAG, "Login Response: " + response);

                if (response != null) {
                    try{
                        JSONObject obj  = new JSONObject(response);
                        for(int y = 0; y < obj.names().length(); y++){
                            String table = obj.names().getString(y);
                            String value = obj.get(obj.names().getString(y)).toString();
                            value = value.substring(value.indexOf("{"), value.lastIndexOf("}") + 1);


                            db.execSQL("DROP TABLE IF EXISTS " + table);

                            JSONArray p  = obj.getJSONArray(table);
                            String QUERY = "CREATE TABLE " + table + "(";
                            for(int i = 0; i < p.length(); i++){
                                String field = p.getJSONObject(i).getString("Field");
                                String key = p.getJSONObject(i).getString("Key");

                                if(i > 0){
                                    if(key.contains("PRI")){
                                        QUERY = QUERY + ", " + field + " VARCHAR(255) NOT NULL";
                                    }else{
                                        QUERY = QUERY + ", " + field + " TEXT";
                                    }
                                }else{
                                    if(key.contains("PRI")){
                                        QUERY = QUERY + field + " VARCHAR(255) NOT NULL";
                                    } else {
                                        QUERY = QUERY + field + " TEXT";
                                    }
                                }
                            }
                            QUERY = QUERY + ")";
                            db.execSQL(QUERY);
                        }

                        Log.d("", "DATABASE CREATED");
                        hideDialog();

                        session.setLogin(true);
                        Intent intent = new Intent(Login.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.putExtra("EXIT", true);
                        startActivity(intent);
                        finish();

                    }catch (JSONException ex){
                        Log.e("JSONError", ex.getMessage());
                        Toast.makeText(getApplicationContext(),
                                "JSON Error: Unable to Create Local Database!", Toast.LENGTH_LONG).show();
                        hideDialog();
                    }
                } else {
                    Log.e("ResponseError", "Response Null");
                    Toast.makeText(getApplicationContext(),
                            "Response Error: Unable to Create Local Database!", Toast.LENGTH_LONG).show();
                    hideDialog();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        "Unable to Create Local Database!", Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                try{
                    params.put("tag", "create_database");
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){ }
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(srq, tag_req);
    }


    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(Login.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(Login.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
}
