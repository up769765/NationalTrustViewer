package com.uk.nationaltrustviewer.classes.place;

import android.widget.Filter;
import java.util.ArrayList;
import java.util.List;

public class PlaceFilter extends Filter {

    private PlacesAdapter adapter;
    private List<Place> filterList;

    public PlaceFilter(List<Place> filterList, PlacesAdapter adapter) {
        this.adapter = adapter;
        this.filterList = filterList;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        if(constraint != null && constraint.length() > 0)
        {
            constraint = constraint.toString().toUpperCase();
            ArrayList<Place> filteredData = new ArrayList<>();
            for (int i=0;i<filterList.size();i++) {
                if(filterList.get(i).getName().toUpperCase().contains(constraint)) {
                    filteredData.add(filterList.get(i));
                }
            }
            results.count = filteredData.size();
            results.values = filteredData;
        }else {
            results.count=filterList.size();
            results.values=filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
       adapter.data = (ArrayList<Place>) results.values;
        adapter.notifyDataSetChanged();
    }
}
