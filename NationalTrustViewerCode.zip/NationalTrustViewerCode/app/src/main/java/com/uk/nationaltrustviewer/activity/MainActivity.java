package com.uk.nationaltrustviewer.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.classes.review.Review;
import com.uk.nationaltrustviewer.classes.review.ReviewAdapter;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    public DatabaseHandler db;
    public SessionManager session;

    private ArrayList<Review> dataList;
    private SwipeRefreshLayout swipeContainer;
    private ReviewAdapter mAdapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        session = new SessionManager(getApplicationContext());
        if (!session.isLoggedIn()) {
            Intent intent = new Intent(MainActivity.this, Login.class);
            startActivity(intent);
            finish();
        }else {
            initViews();
            syncDatabase();
            checkPermission();
        }
    }

    private  void initViews(){
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new DatabaseHandler(this);
        dataList = new ArrayList<>();
        swipeContainer = findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                syncDatabase();
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(R.color.colorAccent);
        recyclerView = findViewById(R.id.recycler_view);
        mAdapter = new ReviewAdapter(getApplicationContext(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                intent.putExtra("place_id", "");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        navigationView.setNavigationItemSelectedListener(this);

        TextView accountName = headerView.findViewById(R.id.accountName);
        TextView accountEmail = headerView.findViewById(R.id.accountEmail);
        accountName.setText(session.getV("ACCOUNT_NAME"));
        accountEmail.setText(session.getV("ACCOUNT_USERNAME")) ;

        loadLocal();
    }

    private void loadLocal(){
        dataList.clear();
        List<Review> data = db.getReviewsByGroup();
        dataList.addAll(data);
        mAdapter.notifyDataSetChanged();
        new LoadMapAsync().execute();
    }

    class LoadMapAsync extends AsyncTask<Void, Integer, String>
    {
        String TAG = getClass().getSimpleName() + "-MAP: ";

        protected void onPreExecute (){
            super.onPreExecute();
            if(AppConfig.DEBUG){ Log.d(TAG + " PreExceute","On pre Exceute......"); }
        }

        protected String doInBackground(Void...arg0) {
            if(AppConfig.DEBUG){ Log.d(TAG + " DoINBackGround","On doInBackground..."); }
            return "You are at PostExecute";
        }

        protected void onProgressUpdate(Integer...a){
            super.onProgressUpdate(a);
            if(AppConfig.DEBUG){ Log.d(TAG + " onProgressUpdate", "You are in progress update ... " + a[0]); }
        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if(AppConfig.DEBUG){ Log.d(TAG + " onPostExecute", "" + result); }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_dash) {

        } else if (id == R.id.nav_map) {
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("place_id", "");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } else if (id == R.id.nav_places) {
            Intent i = new Intent(getApplicationContext(), Places.class);
            startActivity(i);
        } else if (id == R.id.nav_hist) {
            Intent i = new Intent(getApplicationContext(), History.class);
            startActivity(i);
        } else if (id == R.id.nav_account) {
            Intent i = new Intent(getApplicationContext(), Profile.class);
            startActivity(i);
        } else if (id == R.id.nav_signout) {
            signOut();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void syncDatabase() {
        final SQLiteDatabase dbX = db.getWritableDatabase();
        String tag_string_req = "syncDatabase";
        pDialog.setMessage("Syncing ...");
        showDialog();
        StringRequest strReq = new StringRequest(com.android.volley.Request.Method.POST, AppConfig.URL_GET_ALL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                if(AppConfig.DEBUG){Log.d(TAG, "Response: " + response);}
                if (response != null) {
                    try{
                        JSONObject res  = new JSONObject(response);
                        String tables = "tables";
                        JSONArray arrTable = res.getJSONArray(tables);

                        for (int t =0; t < arrTable.length(); t++) {
                            JSONObject objTable  = arrTable.getJSONObject(t);
                            String table = objTable.names().getString(0);

                            if(AppConfig.DEBUG) {Log.d("TABLE:", table);}

                            JSONArray p = objTable.getJSONArray(table);
                            dbX.delete(table, null, null);

                            for (int i =0; i < p.length(); i++) {
                                ContentValues values = new ContentValues();
                                JSONObject row = p.getJSONObject(i);
                                for(int r = 0; r < row.length(); r++){
                                    values.put(row.names().getString(r), row.get(row.names().getString(r)).toString());
                                }
                                dbX.insert(table, null, values);
                            }
                        }
                        db.close();
                        loadLocal();
                        hideDialog();
                    }catch (JSONException ex){
                        showError("Response Error", ex.getMessage());
                        hideDialog();
                    }
                } else {
                    showError("Error", "Response is empty!");
                    hideDialog();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(), "Connection Failed!", Toast.LENGTH_LONG).show();
                hideDialog();
                loadLocal();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "sync_database");
                params.put("id", session.getV("ACCOUNT_ID"));
                params.put("API_KEY", AppConfig.API_KEY);
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void savePlaces() {

        String tag_string_req = "save_places";

        pDialog.setMessage("Saving ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL_PLACES_SAVE, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                if(DEBUG) { Log.d("SAVE_RATES_RESPONSE", "Response: " + response.toString()); }
                Toast.makeText(MainActivity.this, "Successful!", Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if(DEBUG) { Log.e("SAVE_PLACES_ERROR", "Error: " + error.getMessage()); }
                Toast.makeText(MainActivity.this, "Connection Failed!", Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {

                JSONArray jsonArray = new JSONArray();
                List<Place> s = db.getPlaces();
                for (Place x : s) {
                    JSONObject p = new JSONObject();
                    //try {
                    try{
                        p.put("id", x.getId());
                        p.put("name", x.getName());
                        p.put("lat", x.getLat());
                        p.put("lng", x.getLng());
                        p.put("lng", x.getLng());

                    } catch (JSONException e) { if(DEBUG) { Log.e("SAVE_PLACES_ERROR", "Error: " + e.getMessage()); } }
                    jsonArray.put(p);
                }

                JSONObject pricesObj = new JSONObject();
                try {
                    pricesObj.put("places", jsonArray);
                } catch (JSONException e) {}
                String jsonStr = pricesObj.toString();

                Map<String, String> params = new HashMap<String, String>();

                Log.e("PLACES JSON: ", jsonStr);
                try{
                    params.put("tag", "save_places");
                    params.put("username", session.getV("ACCOUNT_ID"));
                    params.put("places_values", jsonStr);
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){}

                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void signOut(){
        LayoutInflater li = LayoutInflater.from(MainActivity.this);
        View promptsView = li.inflate(R.layout.confirm_signout, null);
        AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
        adb.setView(promptsView);
        adb
                .setCancelable(false)
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                session.setLogin(false);
                                Intent i = new Intent(MainActivity.this, Login.class);
                                startActivity(i);
                                finish();
                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alertDialog = adb.create();
        alertDialog.show();
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(MainActivity.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(MainActivity.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void checkPermission(){
        int MyVersion = Build.VERSION.SDK_INT;
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
            if ((ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    || (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)){
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }
        }
    }
}
