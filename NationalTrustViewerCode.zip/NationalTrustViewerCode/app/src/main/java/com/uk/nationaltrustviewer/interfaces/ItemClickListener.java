package com.uk.nationaltrustviewer.interfaces;

import android.view.View;

/**
 * Created by Hp on 3/17/2016.
 */
public interface ItemClickListener {

    void onItemClick(View v, int pos);

}
