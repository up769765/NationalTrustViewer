package com.uk.nationaltrustviewer.classes.review;

public class Review {

    private String id = null;
    private String reviewRate = null;
    private String reviewDesc = null;
    private String userID = null;
    private String userName = null;
    private String userEmail = null;
    private String placeID = null;
    private String placeName = null;
    private String lat = null;
    private String lng = null;
    private String markerColor = null;
    private String date_added = null;
    public Review(){ }

    public Review(
        String id,
        String reviewRate,
        String reviewDesc,
        String userID,
        String userName,
        String userEmail,
        String placeID,
        String placeName,
        String lat,
        String lng,
        String markerColor,
        String date_added
    ){
        super();
        this.id = id;
        this.reviewRate = reviewRate;
        this.reviewDesc = reviewDesc;
        this.userID = userID;
        this.userName = userName;
        this.userEmail = userEmail;
        this.placeID = placeID;
        this.placeName = placeName;
        this.lat = lat;
        this.lng = lng;
        this.markerColor = markerColor;
        this.date_added = date_added;
    }

    public  String getId(){ return id; }
    public void setId(String v){ this.id = v; }

    public  String getReviewRate(){ return reviewRate; }
    public void setReviewRate(String v){ this.reviewRate = v; }

    public  String getReviewDesc(){ return reviewDesc; }
    public void setReviewDesc(String v){ this.reviewDesc = v; }

    public  String getUserID(){ return userID; }
    public void setUserID(String v){ this.userID = v; }

    public  String getUserName(){ return userName; }
    public void setUserName(String v){ this.userName = v; }

    public  String getUserEmail(){ return userEmail; }
    public void setUserEmail(String v){ this.userEmail = v; }

    public  String getPlaceID(){ return placeID; }
    public void setPlaceID(String v){ this.placeID = v; }

    public  String getPlaceName(){ return placeName; }
    public void setPlaceName(String v){ this.placeName = v; }

    public  String getLat(){ return lat; }
    public void setLat(String v){ this.lat = v; }

    public  String getLng(){ return lng; }
    public void setLng(String v){ this.lng = v; }

    public  String getMarkerColor(){ return markerColor; }
    public void setMarkerColor(String v){ this.markerColor = v; }

    public  String getDate_added(){ return date_added; }
    public void setDate_added(String v){ this.date_added = v; }
}
