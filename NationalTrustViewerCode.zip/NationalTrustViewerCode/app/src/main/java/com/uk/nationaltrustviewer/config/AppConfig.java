package com.uk.nationaltrustviewer.config;

public class AppConfig {

    public static String SERVER_URL = "http://national-trust-viewer.co.uk/api/";

    public static boolean DEBUG = false;

    public static String API_KEY = "WTFGHNFIORTURTSDFF3467RTHFNJSDF2349";

    public static String URL_REGISTER = SERVER_URL + "register.php";
    public static String URL_LOGIN = SERVER_URL + "login.php";
    public static String URL_CREATE_DB = SERVER_URL + "create_db.php";
    public static String URL_GET_ALL = SERVER_URL + "get_all.php";
    public static String URL_FORGOT_PASSWORD = SERVER_URL + "forgot_password.php";
    public static String URL_PLACES_SAVE = SERVER_URL + "places_save.php";
    public static String URL_SUBMIT_REVIEW = SERVER_URL + "submit_review.php";
    public static String URL_CHANGE_PASSWORD = SERVER_URL + "change_password.php";
    public static String URL_SAVE_MARKER_COLOR = SERVER_URL + "save_marker_color.php";
}
