package com.uk.nationaltrustviewer.classes.place;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.uk.nationaltrustviewer.activity.MapsActivity;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.activity.StreetView;
import com.uk.nationaltrustviewer.interfaces.ItemClickListener;

import java.util.List;

public class PlacesAdapter extends RecyclerView.Adapter<PlacesAdapter.MyViewHolder> implements Filterable {

    public List<Place> data;
    private Context context;
    private List<Place> filterList;
    private PlaceFilter filter;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name;
        public LinearLayout buttonStreetview;

        ItemClickListener itemClickListener;
        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.name);
            buttonStreetview = view.findViewById(R.id.buttonStreetview);
            view.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemClick(v,getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListener ic)
        {
            this.itemClickListener=ic;
        }
    }

    public PlacesAdapter(Context context, List<Place> data) {
        this.data = data;
        this.context = context;
        this.filterList = data;
    }

    @Override
    @NonNull
    public MyViewHolder  onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout. template_place, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        Place d = data.get(position);
        String name = d.getId() + ": " + d.getName();
        holder.name.setText(name);

        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View v, int pos) {
                //Snackbar.make(v, data.get(pos).getName(),Snackbar.LENGTH_SHORT).show();

                Intent intent = new Intent(context, MapsActivity.class);
                intent.putExtra("place_id", data.get(pos).getId());
                intent.putExtra("place_name", data.get(pos).getName());
                intent.putExtra("place_lat", data.get(pos).getLat());
                intent.putExtra("place_lng", data.get(pos).getLng());

                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });

        holder.buttonStreetview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, StreetView.class);
                intent.putExtra("place_name", data.get(position).getName());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public Filter getFilter() {
        if(filter == null) {
            filter = new PlaceFilter(filterList, this);
        }
        return filter;
    }
}
