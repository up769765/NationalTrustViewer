package com.uk.nationaltrustviewer.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.classes.review.HistoryAdapter;
import com.uk.nationaltrustviewer.classes.review.Review;
import com.uk.nationaltrustviewer.classes.review.ReviewAdapter;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class History extends AppCompatActivity {

    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = History.class.getSimpleName();
    private ProgressDialog pDialog;
    private DatabaseHandler db;
    public SessionManager session;

    private ArrayList<Review> dataList;
    private SwipeRefreshLayout swipeContainer;
    private HistoryAdapter mAdapter;
    private RecyclerView recyclerView;
    private Button viewOnMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);
        session = new SessionManager(getApplicationContext());
        if (!session.isLoggedIn()) {
            Intent intent = new Intent(History.this, Login.class);
            startActivity(intent);
            finish();
        }else {
            initViews();
            loadLocal();
        }
    }

    private  void initViews(){
        db = new DatabaseHandler(this);
        dataList = new ArrayList<>();
        swipeContainer = findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadLocal();
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(R.color.colorAccent);
        recyclerView = findViewById(R.id.recycler_view);
        mAdapter = new HistoryAdapter(getApplicationContext(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        viewOnMap = findViewById(R.id.viewOnMap);
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        viewOnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MapsHistory.class);
                startActivity(i);
            }
        });
    }

    private void loadLocal(){
        dataList.clear();
        List<Review> data = db.getHistory(session.getV("ACCOUNT_ID"));
        dataList.addAll(data);
        mAdapter.notifyDataSetChanged();
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(History.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(History.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }

}
