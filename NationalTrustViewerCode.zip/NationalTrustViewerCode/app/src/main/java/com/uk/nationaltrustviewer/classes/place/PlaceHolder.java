package com.uk.nationaltrustviewer.classes.place;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.interfaces.ItemClickListener;

public class PlaceHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    ItemClickListener itemClickListener;
    TextView name;

    public PlaceHolder(View view) {
        super(view);
        this.name = (TextView) view.findViewById(R.id.name);

        view.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClick(v,getLayoutPosition());

    }

    public void setItemClickListener(ItemClickListener ic)
    {
        this.itemClickListener=ic;
    }

}
