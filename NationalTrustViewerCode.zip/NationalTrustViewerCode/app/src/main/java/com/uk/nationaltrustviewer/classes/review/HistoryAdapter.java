package com.uk.nationaltrustviewer.classes.review;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.skydoves.colorpickerpreference.ColorEnvelope;
import com.skydoves.colorpickerpreference.ColorListener;
import com.skydoves.colorpickerpreference.ColorPickerView;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.activity.MainActivity;
import com.uk.nationaltrustviewer.activity.StreetView;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.interfaces.ItemClickListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyViewHolder>{

    public List<Review> data;
    private Context context;
    private String selectedMarkerColor;
    public DatabaseHandler db;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView placeName, content, dateAdded;
        public RatingBar ratingBar;
        public LinearLayout buttonStreetview;
        public LinearLayout markerColor;

        ItemClickListener itemClickListener;
        public MyViewHolder(View view) {
            super(view);
            placeName = view.findViewById(R.id.placeName);
            content = view.findViewById(R.id.content);
            ratingBar = view.findViewById(R.id.ratingBar);
            dateAdded = view.findViewById(R.id.dateAdded);
            buttonStreetview = view.findViewById(R.id.buttonStreetview);
            markerColor = view.findViewById(R.id.markerColor);
            db = new DatabaseHandler(context);
            view.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemClick(v,getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListener ic)
        {
            this.itemClickListener=ic;
        }
    }

    public HistoryAdapter(Context context, List<Review> data) {
        this.data = data;
        this.context = context;
    }

    @Override
    @NonNull
    public MyViewHolder  onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout. template_history, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final Review d = data.get(position);

        holder.placeName.setText(d.getPlaceName());
        holder.content.setText(d.getReviewDesc());
        float rating = Float.parseFloat(d.getReviewRate());
        holder.ratingBar.setRating(rating);
        holder.markerColor.setBackgroundColor(Color.parseColor(d.getMarkerColor()));

        try {
            SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            Date date = dt.parse(d.getDate_added());
            SimpleDateFormat dt1 = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
            holder.dateAdded.setText(dt1.format(date));
        } catch(ParseException ex){
            Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        holder.buttonStreetview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, StreetView.class);
                intent.putExtra("place_name", data.get(position).getPlaceName());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

        holder.markerColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LayoutInflater factory = LayoutInflater.from(v.getContext());
                final View deleteDialogView = factory.inflate(R.layout.color_picker, null);
                final AlertDialog deleteDialog = new AlertDialog.Builder(v.getContext()).create();
                deleteDialog.setView(deleteDialogView);

                ColorPickerView colorPickerView;
                colorPickerView = deleteDialogView.findViewById(R.id.colorPickerView);
                colorPickerView.setColorListener(new ColorListener() {
                    @Override
                    public void onColorSelected(ColorEnvelope colorEnvelope) {
                        holder.markerColor.setBackgroundColor(colorEnvelope.getColor());
                        selectedMarkerColor = colorEnvelope.getColorHtml();
                    }
                });

                 deleteDialogView.findViewById(R.id.saveButton).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        saveColor(d.getId(), selectedMarkerColor);
                        deleteDialog.dismiss();
                    }
                });
                deleteDialog.show();

            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    /*private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }*/

    //private ProgressDialog pDialog;

    private void saveColor(final String id, final String markerColor) {

        String tag_string_req = "save_color";

        /*pDialog = new ProgressDialog(context);
        pDialog.setCancelable(false);
        pDialog.setMessage("Saving ...");
        showDialog();*/

        StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL_SAVE_MARKER_COLOR, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                if(response.contains("@Error: ")){
                    Toast.makeText(context, response.replace("@Error: ", ""), Toast.LENGTH_LONG).show();

                }else{
                    if(response.contains("@Success: ")){
                        String res = response.replace("@Success: ", "");
                        Toast.makeText(context, res, Toast.LENGTH_LONG).show();
                        String color = "#" + markerColor;
                        db.updateMarkerColor(id, color);
                    }else{
                        Toast.makeText(context, "Server connection failed!", Toast.LENGTH_LONG).show();
                    }
                }

                //hideDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Connection Failed!", Toast.LENGTH_LONG).show();
                //hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                try{
                    params.put("tag", "save_color");
                    params.put("review_id", id);
                    params.put("markerColor", markerColor);
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){}

                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }
}
