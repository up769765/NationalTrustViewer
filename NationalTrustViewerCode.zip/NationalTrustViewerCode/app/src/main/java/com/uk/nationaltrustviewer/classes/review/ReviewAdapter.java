package com.uk.nationaltrustviewer.classes.review;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.RatingBar;
import android.widget.TextView;

import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.activity.MapsActivity;
import com.uk.nationaltrustviewer.activity.ReviewDetalis;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.classes.place.PlaceFilter;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.interfaces.ItemClickListener;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.MyViewHolder> implements Filterable {

    public List<Review> data;
    private Context context;
    private List<Review> filterList;
    private ReviewFilter filter;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView placeName, content, dateAdded;
        public RatingBar rating;

        ItemClickListener itemClickListener;
        public MyViewHolder(View view) {
            super(view);
            placeName = view.findViewById(R.id.placeName);
            content = view.findViewById(R.id.content);
            dateAdded = view.findViewById(R.id.dateAdded);
            rating = view.findViewById(R.id.ratingBar);
            view.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemClick(v,getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListener ic)
        {
            this.itemClickListener=ic;
        }
    }

    public ReviewAdapter(Context context, List<Review> data) {
        this.data = data;
        this.context = context;
        this.filterList = data;
    }

    @Override
    @NonNull
    public MyViewHolder  onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout. template_review, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Review d = data.get(position);
        holder.placeName.setText(
                d.getPlaceName());
        holder.content.setText(d.getReviewDesc());
        holder.dateAdded.setText(d.getDate_added());
        float rate = Float.parseFloat(d.getReviewRate());
        holder.rating.setRating(rate);
        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View v, int pos) {
                Intent intent = new Intent(context, ReviewDetalis.class);
                String id = data.get(pos).getPlaceID();
                intent.putExtra("place_id", id);
                intent.putExtra("place_name", data.get(pos).getPlaceName());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public Filter getFilter() {
        if(filter == null) {
            filter = new ReviewFilter(filterList, this);
        }
        return filter;
    }
}
