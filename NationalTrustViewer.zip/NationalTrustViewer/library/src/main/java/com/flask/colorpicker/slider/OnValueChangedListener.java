package com.flask.colorpicker.slider;

public interface OnValueChangedListener {
	void onValueChanged(float value);
}