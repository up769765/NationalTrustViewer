package com.uk.nationaltrustviewer.classes;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {

    private static final String EMAIL_REGEX = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    private static final String PHONE_REGEX = "\\d{3}-\\d{7}";

    // Error Messages
    private static final String REQUIRED_MSG = "Required";
    private static final String REQUIRED_SELECT_MSG = "Selection required";
    private static final String EMAIL_MSG = "Invalid email address";
    private static final String PHONE_MSG = "###-#######";
    private static final String EQUAL_MSG = "Must be equal";
    private static final String URL_MSG = "Invalid URL";

    public static boolean isEmailAddress(EditText editText, boolean required) {
        return isValid(editText, EMAIL_REGEX, EMAIL_MSG, required);
    }

    public static boolean isPhoneNumber(EditText editText, boolean required) {
        return isValid(editText, PHONE_REGEX, PHONE_MSG, required);
    }

    public static boolean isValid(EditText editText, String regex, String errMsg, boolean required) {

        String text = editText.getText().toString().trim();
        editText.setError(null);
        if ( required && !hasText(editText) ) return false;

        if (required && !Pattern.matches(regex, text)) {
            editText.setError(errMsg);
            return false;
        }

        return true;
    }

    public static boolean hasText(EditText editText) {
        String text = editText.getText().toString().trim();
        editText.setError(null);
        if (text.length() == 0) {
            editText.setError(REQUIRED_MSG);
            return false;
        }
        return true;
    }
    public static boolean hasSelected(Spinner spinner) {
        String text = spinner.getSelectedItem().toString().trim();
        View selectedView = spinner.getSelectedView();
        if (selectedView != null && selectedView instanceof TextView) {
            TextView selectedTextView = (TextView) selectedView;
            if (text.length() == 0 || spinner.getSelectedItemPosition() == 0) {
                selectedTextView.setError(REQUIRED_SELECT_MSG);
                return false;
            }
            else {
                selectedTextView.setError(null);
            }
        }
        return true;
    }
    public static boolean isChecked(RadioGroup radioGroup) {
        if(radioGroup.getCheckedRadioButtonId()<=0){
            View o = radioGroup.getChildAt(0);
            if (o instanceof RadioButton) {
                RadioButton radio = (RadioButton)o;
                radio.setError(REQUIRED_SELECT_MSG);
                return false;
            }
        }
        return true;
    }

    public static boolean isEqual(EditText editText1, EditText editText2) {
        String text1 = editText1.getText().toString().trim();
        String text2 = editText2.getText().toString().trim();
        //editText1.setError(null);
        //editText2.setError(null);
        if (!text1.equals(text2)) {
            editText1.setError(EQUAL_MSG);
            editText2.setError(EQUAL_MSG);
            return false;
        }
        return true;
    }

    public static boolean isValidUrl(EditText url) {
        String link = url.getText().toString();
        Pattern p = Patterns.WEB_URL;
        Matcher m = p.matcher(link.toLowerCase());
        if (!m.matches()) {
            url.setError(URL_MSG);
        }
        return m.matches();
    }

}
