package com.uk.nationaltrustviewer.activity;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.DrawableRes;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.InfoWindowCustom;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.util.List;

public class MapsHistory extends FragmentActivity implements OnMapReadyCallback {

    private boolean isMapLoaded = false;
    private GoogleMap mMap;
    private DatabaseHandler db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        try{
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                Window window = this.getWindow();
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
            }
        }catch(Exception ex){
            showError("TRANSLUCENT ERROR: ", ex.getMessage());
        }

        session = new SessionManager(getApplicationContext());
        db = new DatabaseHandler(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        LatLng latlng = new LatLng(51.442970, -1.876731);
        mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(latlng, 7.0f) );
        loadLocations();

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Intent intent = new Intent(MapsHistory.this, WriteReview.class);
                intent.putExtra("placeID", marker.getSnippet());
                intent.putExtra("placeName", marker.getTitle());
                startActivity(intent);
            }
        });


    }

    private BitmapDescriptor bitmapDescriptorFromVector(String color, Context context, @DrawableRes int vectorDrawableResourceId) {

        Drawable background = ContextCompat.getDrawable(context, R.drawable.ic_map);
        background.setTint(Color.parseColor(color));
        background.setBounds(0, 0, background.getIntrinsicWidth() + 50, background.getIntrinsicHeight() + 50);
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorDrawableResourceId);
        vectorDrawable.setColorFilter(Color.GREEN, PorterDuff.Mode.OVERLAY);
        //vectorDrawable.setBounds(40, 20, vectorDrawable.getIntrinsicWidth() + 40, vectorDrawable.getIntrinsicHeight() + 20);
        Bitmap bitmap = Bitmap.createBitmap(background.getIntrinsicWidth(), background.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        background.draw(canvas);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    class LoadMapAsync extends AsyncTask<String, Integer, String>
    {
        String TAG = getClass().getSimpleName();
        String id, name, lat, lng, color;

        protected void onPreExecute (){
            super.onPreExecute();
            Log.d(TAG + " PreExceute","On pre Exceute......");
        }

        protected String doInBackground(String...arg0) {
            Log.d(TAG + " DoINBackGround","On doInBackground...");

            id = arg0[0];
            name = arg0[1];
            lat = arg0[2];
            lng = arg0[3];
            color = arg0[4];
            return "You are at PostExecute";
        }

        protected void onProgressUpdate(Integer...a){
            super.onProgressUpdate(a);
            Log.d(TAG + " onProgressUpdate", "You are in progress update ... " + a[0]);
        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.d(TAG + " onPostExecute", "" + result);

            final double latitude = Double.parseDouble( lat );
            final double longitude = Double.parseDouble( lng );

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    LatLng latlng = new LatLng(latitude, longitude);
                    //Marker marker = mMap.addMarker(new MarkerOptions().position(latlng) .icon(BitmapDescriptorFactory.fromResource(R.drawable.map_marker_violet)) .title(name).snippet(id));
                    Marker marker = mMap.addMarker(new MarkerOptions().position(latlng) .icon(bitmapDescriptorFromVector(color, getApplicationContext(), R.drawable.ic_map)) .title(name).snippet(id));
                    mMap.setInfoWindowAdapter(new InfoWindowCustom(getApplicationContext()));
                }
            });
        }
    }

    private void loadLocations(){
        try{
            List<Place> proj = db.getPlacesVisited(session.getV("ACCOUNT_ID"));
            for (Place x : proj) {
                if(!x.getLat().isEmpty()){
                    String id = x.getId();
                    String name = x.getName();
                    new LoadMapAsync().execute(id, name, x.getLat(), x.getLng(), x.getColor());
                }
            }
        } catch (Exception ex){

        }
    }
    public static void displayPromptForEnablingGPS(final Activity activity) {

        final AlertDialog.Builder builder =  new AlertDialog.Builder(activity);
        final String action = Settings.ACTION_LOCATION_SOURCE_SETTINGS;
        final String message = "Do you want open GPS setting?";

        builder.setMessage(message)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int id) {
                                activity.startActivity(new Intent(action));
                                d.dismiss();
                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int id) {
                                d.cancel();
                            }
                        });
        builder.create().show();
    }

    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(MapsHistory.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(MapsHistory.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }

}


