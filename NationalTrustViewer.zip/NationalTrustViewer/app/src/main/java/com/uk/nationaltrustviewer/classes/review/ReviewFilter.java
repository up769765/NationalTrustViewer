package com.uk.nationaltrustviewer.classes.review;

import android.widget.Filter;

import java.util.ArrayList;
import java.util.List;

public class ReviewFilter extends Filter {

    private ReviewAdapter adapter;
    private List<Review> filterList;

    public ReviewFilter(List<Review> filterList, ReviewAdapter adapter) {
        this.adapter = adapter;
        this.filterList = filterList;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        if(constraint != null && constraint.length() > 0)
        {
            constraint = constraint.toString().toUpperCase();
            ArrayList<Review> filteredData = new ArrayList<>();
            for (int i=0;i<filterList.size();i++) {
                if(filterList.get(i).getPlaceName().toUpperCase().contains(constraint)) {
                    filteredData.add(filterList.get(i));
                }
            }
            results.count = filteredData.size();
            results.values = filteredData;
        }else {
            results.count=filterList.size();
            results.values=filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapter.data = (ArrayList<Review>) results.values;
        adapter.notifyDataSetChanged();
    }
}
