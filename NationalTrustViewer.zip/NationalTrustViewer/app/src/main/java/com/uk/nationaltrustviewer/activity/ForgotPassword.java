package com.uk.nationaltrustviewer.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.ValidateEmail;
import com.uk.nationaltrustviewer.classes.Validation;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.util.HashMap;
import java.util.Map;

public class ForgotPassword extends AppCompatActivity {
    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = ForgotPassword.class.getSimpleName();

    private EditText inputEmail;
    private Button btnSend;
    private ProgressDialog pDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_password);
        getSupportActionBar().setElevation(0);
        initViews();
    }

    private void initViews() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        inputEmail = (EditText) findViewById(R.id.email);
        inputEmail.addTextChangedListener(new ValidateEmail(this,inputEmail, true));

        btnSend = (Button) findViewById(R.id.btnSend);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()) {
                    submitForm();
                } else {
                    Toast.makeText(ForgotPassword.this, "Form contains error", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean validate() {
        boolean ret = true;
        if (!Validation.isEmailAddress(inputEmail, true)) ret = false;
        return ret;
    }

    private void submitForm() {
        String tag_string_req = "req_forgot_password";
        pDialog.setMessage("Processing ...");
        showDialog();
        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_FORGOT_PASSWORD, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Response: " + response);
                hideDialog();
                if(response.contains("@Error: ")){
                    showError("Failed", response.replace("@Error: ", ""));
                }else{
                    if(response.contains("@Success: ")){
                        String res = response.replace("@Success: ", "");
                        showOK("Successful", res);

                        inputEmail.setText("");

                    }else{
                        showError("Failed", "Server connection failed!");
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                showError("Failed!", "Please check your internet connection!");
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                try{
                    params.put("email", inputEmail.getText().toString());
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){
                    Log.e("MCrypt Error", ex.getMessage());
                }
                return params;
            }

        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(ForgotPassword.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(ForgotPassword.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
