package com.uk.nationaltrustviewer.classes.place;

public class Place {

    private String id = null;
    private String name = null;
    private String lat = null;
    private String lng = null;
    private  String color = null;

    public Place(){ }

    public Place (String id, String name, String lat, String lng, String color){
        super();
        this.id = id;
        this.name = name;
        this.lat = lat;
        this.lng = lng;
        this.color = color;
    }

    public  String getId(){ return id; }
    public void setId(String v){ this.id = v; }

    public  String getName(){ return name; }
    public void setName(String v){ this.name = v; }

    public  String getLat(){ return lat; }
    public void setLat(String v){ this.lat = v; }

    public  String getLng(){ return lng; }
    public void setLng(String v){ this.lng = v; }

    public  String getColor(){ return color; }
    public void setColor(String v){ this.color = v; }
}
