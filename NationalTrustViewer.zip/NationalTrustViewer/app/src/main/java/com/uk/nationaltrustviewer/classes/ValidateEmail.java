package com.uk.nationaltrustviewer.classes;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class ValidateEmail implements TextWatcher {
    private Context mContext;
    EditText editText;
    boolean required;

    public ValidateEmail(Context context, EditText editText, boolean required) {
        super();
        this.mContext = context;
        this.editText = editText;
        this.required = required;
    }

    @Override
    public void afterTextChanged(Editable s) {
        Validation.isEmailAddress(editText, required);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
                                  int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}
