package com.uk.nationaltrustviewer.config;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SessionManager {
	private static String TAG = SessionManager.class.getSimpleName();
	SharedPreferences pref;
	Editor editor;
	Context _context;
	int PRIVATE_MODE = 0;
	private static final String PREF_NAME = "NationalTrustViewerSession";
	private static final String KEY_IS_LOG = PREF_NAME + "IsLoggedIn";

	public SessionManager(Context context) {
		this._context = context;
		pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
		editor = pref.edit();
	}

	public void setLogin(boolean isLoggedIn) {
		editor.putBoolean(KEY_IS_LOG, isLoggedIn);
		editor.commit();
	}
	public boolean isLoggedIn(){
		return pref.getBoolean(KEY_IS_LOG, false);
	}

	public void setV(String p, String v){
		editor.putString(PREF_NAME + p, v); editor.commit();
	}
	public String getV(String p){
		return pref.getString(PREF_NAME + p, "");
	}

}
