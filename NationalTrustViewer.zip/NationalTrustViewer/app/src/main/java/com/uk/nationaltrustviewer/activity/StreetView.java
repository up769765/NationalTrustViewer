package com.uk.nationaltrustviewer.activity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.StreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.uk.nationaltrustviewer.R;

import java.io.IOException;
import java.util.List;

public class StreetView extends FragmentActivity implements OnStreetViewPanoramaReadyCallback {

    StreetViewPanorama panorama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.street_view);

        StreetViewPanoramaFragment streetViewPanoramaFragment =
                (StreetViewPanoramaFragment) getFragmentManager()
                        .findFragmentById(R.id.streetviewpanorama);
        streetViewPanoramaFragment.getStreetViewPanoramaAsync(this);
    }

    @Override
    public void onStreetViewPanoramaReady(StreetViewPanorama p) {
        panorama = p;

        Intent myIntent = getIntent();
        String name = myIntent.getStringExtra("place_name");

        LatLng latLng = getLocationFromAddress(name + ", UK");
        panorama.setPosition(latLng);
    }

    private LatLng getLocationFromAddress(String strAddress) {
        Geocoder coder = new Geocoder(this);
        List<Address> address;
        LatLng latLng = new LatLng(14.6565277,121.0595733);
        try {
            address = coder.getFromLocationName(strAddress,5);
            if (address == null) {
                return latLng;
            }
            Address location=address.get(0);
            latLng = new LatLng(location.getLatitude(), location.getLongitude());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return latLng;
    }

}
