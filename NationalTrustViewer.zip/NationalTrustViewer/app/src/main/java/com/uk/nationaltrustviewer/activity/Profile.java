package com.uk.nationaltrustviewer.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.Validation;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.util.HashMap;
import java.util.Map;

public class Profile extends AppCompatActivity {
    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = Profile.class.getSimpleName();

    EditText inputName;
    EditText inputEmail;
    EditText inputPassword;
    EditText inputConfirmPassword;
    EditText inputOldPassword;
    Button btnRegister;
    ProgressDialog pDialog;
    TextView registerStatus;
    AlertDialog.Builder adb;
    AlertDialog alertDialog;
    public SessionManager session;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        getSupportActionBar().setElevation(0);
        session = new SessionManager(getApplicationContext());
        initViews();
    }

    private void initViews() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        inputName = findViewById(R.id.name);
        inputEmail = findViewById(R.id.email);

        inputName.setText(session.getV("ACCOUNT_NAME"));
        inputEmail.setText(session.getV("ACCOUNT_USERNAME")) ;

        inputOldPassword = findViewById(R.id.old_password);
        inputPassword = findViewById(R.id.new_password);
        inputConfirmPassword = findViewById(R.id.confirm_password);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()) {
                    changePassword();
                } else {
                    Toast.makeText(Profile.this, "Form contains error", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean validate() {
        boolean ret = true;
        if (!Validation.hasText(inputOldPassword)) ret = false;
        if (!Validation.hasText(inputPassword)) ret = false;
        if (!Validation.hasText(inputConfirmPassword)) ret = false;
        if (!Validation.isEqual(inputPassword, inputConfirmPassword)) ret = false;
        return ret;
    }

    private void changePassword() {
        String tag_string_req = "req_register";
        pDialog.setMessage("Processing ...");
        showDialog();
        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_CHANGE_PASSWORD, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Response: " + response);
                hideDialog();
                if(response.contains("@Error: ")){
                    showError("Failed", response.replace("@Error: ", ""));
                }else{
                    if(response.contains("@Success: ")){
                        String res = response.replace("@Success: ", "");
                        success(res);
                    }else{
                        showError("Failed", "Server connection failed!");
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                showError("Failed!", "Please icon_check your internet connection!");
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                try{
                    params.put("tag", "login");
                    params.put("name", inputName.getText().toString());
                    params.put("email", inputEmail.getText().toString());
                    params.put("old_password", inputOldPassword.getText().toString());
                    params.put("new_password", inputPassword.getText().toString());
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){
                    Log.e("MCrypt Error", ex.getMessage());
                }
                return params;
            }

        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void success(String message){
        LayoutInflater li = LayoutInflater.from(Profile.this);
        View promptsView = li.inflate(R.layout.register_success, null);
        adb = new AlertDialog.Builder(Profile.this);
        adb.setView(promptsView);
        registerStatus = (TextView) promptsView.findViewById(R.id.registerStatus);
        registerStatus.setText(message);
        adb.setCancelable(false);
        alertDialog = adb.create();
        alertDialog.show();
    }

    public void closeRegistration(View view){
        alertDialog.cancel();
        finish();
    }

    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(Profile.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(Profile.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
