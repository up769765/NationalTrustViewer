package com.uk.nationaltrustviewer.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.Validation;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.AppController;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.util.HashMap;
import java.util.Map;

public class WriteReview extends AppCompatActivity {
    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = WriteReview.class.getSimpleName();

    private TextView placeName;
    private EditText reviewContent;
    private RatingBar ratingBar;
    private Button buttonSubmitReview, buttonSaveHistory;
    private ProgressDialog pDialog;
    private String selectedID, selectedName;
    private SessionManager session;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.write_review);
        getSupportActionBar().setElevation(0);
        session = new SessionManager(getApplicationContext());
        initViews();
    }

    private void initViews() {

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        placeName = (TextView)findViewById(R.id.placeName);
        reviewContent = findViewById(R.id.reviewContent);
        ratingBar = findViewById(R.id.ratingBar);

        Intent myIntent = getIntent();
        selectedID = myIntent.getStringExtra("placeID");
        selectedName = myIntent.getStringExtra("placeName");

        placeName.setText(selectedName);

        buttonSubmitReview = findViewById(R.id.buttonSubmitReview);
        buttonSubmitReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()) {
                    submitForm();
                } else {
                    Toast.makeText(WriteReview.this, "Form contains error", Toast.LENGTH_LONG).show();
                }
            }
        });

        buttonSaveHistory = findViewById(R.id.buttonSaveHistory);
        buttonSaveHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitForm();
            }
        });
    }

    private boolean validate() {
        boolean ret = true;
        if (!Validation.hasText(reviewContent)) ret = false;
        return ret;
    }

    private void submitForm() {
        String tag_string_req = "req_submit_review";
        pDialog.setMessage("Sending ...");
        showDialog();
        StringRequest strReq = new StringRequest(Request.Method.POST,
                AppConfig.URL_SUBMIT_REVIEW, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Response: " + response);
                hideDialog();
                if(response.contains("@Error: ")){
                    showError("Failed", response.replace("@Error: ", ""));
                }else{
                    if(response.contains("@Success: ")){
                        String res = response.replace("@Success: ", "");
                        showOK("Successful", res);

                        reviewContent.setText("");
                        ratingBar.setRating(0);
                    }else{
                        showError("Failed", "Server connection failed!");
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error: " + error.getMessage());
                showError("Failed!", "Please check your internet connection!");
                hideDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                try{
                    params.put("placeID", selectedID);
                    params.put("placeName", selectedName);

                    params.put("userID", session.getV("ACCOUNT_ID"));
                    params.put("userName", session.getV("ACCOUNT_NAME"));
                    params.put("userEmail", session.getV("ACCOUNT_USERNAME"));
                    params.put("reviewDesc", reviewContent.getText().toString());
                    params.put("reviewRate", Float.toString(ratingBar.getRating()));
                    params.put("API_KEY", AppConfig.API_KEY);
                }catch (Exception ex){
                    Log.e("MCrypt Error", ex.getMessage());
                }
                return params;
            }

        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(WriteReview.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(WriteReview.this);
        dlgAlert.setMessage(text);
        dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
