package com.uk.nationaltrustviewer.activity;

import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.classes.place.PlacesAdapter;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class Places extends AppCompatActivity implements SearchView.OnQueryTextListener {
    boolean DEBUG = AppConfig.DEBUG;
    private DatabaseHandler db;
    private ArrayList<Place> dataList;
    private SwipeRefreshLayout swipeContainer;
    private PlacesAdapter mAdapter;
    RecyclerView recyclerView;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.places);

        getSupportActionBar().setElevation(0);

        session = new SessionManager(getApplicationContext());
        db = new DatabaseHandler(this);
        dataList = new ArrayList<>();
        swipeContainer = findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                lodLocal();
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(R.color.colorAccent);
        recyclerView = findViewById(R.id.recycler_view);
        mAdapter = new PlacesAdapter(getApplicationContext(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        lodLocal();
    }

    @Override
    public boolean onQueryTextChange(String query) {
        mAdapter.getFilter().filter(query);
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        Log.e("QUERY", query);
        return false;
    }

    private void lodLocal(){
        dataList.clear();
        List<Place> proj = db.getPlaces();
        for (Place x : proj) {
            dataList.add(new Place(x.getId(), x.getName(), x.getLat(), x.getLng(), x.getColor()));
        }
        mAdapter.notifyDataSetChanged();
    }

    private void showError(String title, String message){
        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(Places.this);
        dlgAlert.setMessage(message);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String message){
        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(Places.this);
        dlgAlert.setMessage(message);
        dlgAlert.setIcon(R.drawable.icon_alert);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
       /* menu.add(0, v.getId(), 0, "Delete");
        menu.add(0, v.getId(), 0, "Delete All");*/
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int listPosition = info.position;
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        final MenuItem searchItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(this);
        return true;
    }
}
