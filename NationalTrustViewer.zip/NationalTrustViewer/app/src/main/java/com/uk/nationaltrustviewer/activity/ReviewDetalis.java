package com.uk.nationaltrustviewer.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.classes.review.Review;
import com.uk.nationaltrustviewer.classes.review.ReviewDetailsAdapter;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.config.DatabaseHandler;
import com.uk.nationaltrustviewer.config.SessionManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ReviewDetalis extends AppCompatActivity {

    boolean DEBUG = AppConfig.DEBUG;
    private static final String TAG = ReviewDetalis.class.getSimpleName();
    private ProgressDialog pDialog;
    private DatabaseHandler db;
    public SessionManager session;

    private ArrayList<Review> dataList;
    private SwipeRefreshLayout swipeContainer;
    private ReviewDetailsAdapter mAdapter;
    RecyclerView recyclerView;
    private String selectedPlaceID, selectedPlaceName;
    private TextView placeName;
    private RatingBar rating;
    private float totalRate;
    public LinearLayout buttonStreetview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.review_details);
        session = new SessionManager(getApplicationContext());

        initViews();
        Intent myIntent = getIntent();
        selectedPlaceID = myIntent.getStringExtra("place_id");
        selectedPlaceName = myIntent.getStringExtra("place_name");

        loadLocal();
        placeName.setText(selectedPlaceName);
        if(AppConfig.DEBUG){ Log.d("RATE: ", String.valueOf(totalRate)); }
        totalRate = round(totalRate, 1);
        if(AppConfig.DEBUG){ Log.d("RATE: ", String.valueOf(totalRate)); }
        rating.setRating(totalRate);
    }

    public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }

    private  void initViews(){
        db = new DatabaseHandler(this);
        dataList = new ArrayList<>();
        swipeContainer = findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadLocal();
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(R.color.colorAccent);
        recyclerView = findViewById(R.id.recycler_view);
        mAdapter = new ReviewDetailsAdapter(getApplicationContext(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        placeName = findViewById(R.id.placeName);
        rating = findViewById(R.id.ratingBar);
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        buttonStreetview = findViewById(R.id.buttonStreetview);
        buttonStreetview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), StreetView.class);
                intent.putExtra("place_name", selectedPlaceName);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }

    private void loadLocal(){
        dataList.clear();
        List<Review> data = db.getReviewsByPlaceID(selectedPlaceID);
        int count = 0;
        for (Review x : data) {
            dataList.add(new Review(
                    x.getId(),
                    x.getReviewRate(),
                    x.getReviewDesc(),
                    x.getUserID(),
                    x.getUserName(),
                    x.getUserEmail(),
                    x.getPlaceID(),
                    x.getPlaceName(),
                    x.getLat(),
                    x.getLng(),
                    x.getMarkerColor(),
                    x.getDate_added()
                    )
            );
            float rate = Float.parseFloat(x.getReviewRate());
            totalRate = totalRate + rate;
            count = count + 1;
        }
        totalRate = totalRate / count;
        mAdapter.notifyDataSetChanged();
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void showError(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(ReviewDetalis.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    private void showOK(String title, String text){
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(ReviewDetalis.this);
        dlgAlert.setMessage(text);
        //dlgAlert.setIcon(R.drawable.icon_check);
        dlgAlert.setTitle(title);
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }

}
