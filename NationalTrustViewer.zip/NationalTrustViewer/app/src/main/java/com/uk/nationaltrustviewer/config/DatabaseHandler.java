package com.uk.nationaltrustviewer.config;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.uk.nationaltrustviewer.classes.place.Place;
import com.uk.nationaltrustviewer.classes.review.Review;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "national_trust_viewer_db";

    public Context contextNew;

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        contextNew = context;
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        String qRates = "CREATE TABLE itr_rates(id INT(11) PRIMARY KEY NOT NULL, r_from DOUBLE, r_to DOUBLE, r_value DOUBLE)";
        db.execSQL(qRates);

        String qDash = "CREATE TABLE itr_dash(code TEXT PRIMARY KEY NOT NULL, value TEXT)";
        db.execSQL(qDash);

    }
    // Upgrading Tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        /*db.execSQL("DROP TABLE IF EXISTS transactions");
        db.execSQL("DROP TABLE IF EXISTS transaction_items");*/

        onCreate(db);
    }

    // PLACES ALL
    public List<Place> getPlaces() {
        List<Place> plist = new ArrayList<>();
        String selectQuery = "SELECT * FROM places";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Place d = new Place();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setName(cursor.getString(cursor.getColumnIndex("name")));
                d.setLat(cursor.getString(cursor.getColumnIndex("lat")));
                d.setLng(cursor.getString(cursor.getColumnIndex("lng")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    // PLACES VISITED
   public List<Place> getPlacesVisited(String userID) {
        List<Place> plist = new ArrayList<>();
        String selectQuery = "SELECT places.*, markerColor FROM places LEFT JOIN reviews ON reviews.placeID = places.id WHERE reviews.userID = '" + userID + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Place d = new Place();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setName(cursor.getString(cursor.getColumnIndex("name")));
                d.setLat(cursor.getString(cursor.getColumnIndex("lat")));
                d.setLng(cursor.getString(cursor.getColumnIndex("lng")));
                d.setColor(cursor.getString(cursor.getColumnIndex("markerColor")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    // UPDATE MARKER COLOR
    public void updateMarkerColor(String id, String color) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("markerColor", color);
        db.update("reviews", values, "id=" + id, null);
        db.close();
    }

    // UPDATE PLACES
    public void updateCoordinates(Place d) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("lat", d.getLat());
        values.put("lng", d.getLng());
        db.update("places", values, "id=" + d.getId(), null);
        db.close();
    }

    // GET ALL REVIEWS
    public List<Review> getAllReviews() {
        List<Review> plist = new ArrayList<>();
        String selectQuery = "SELECT * FROM reviews";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Review d = new Review();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setPlaceID(cursor.getString(cursor.getColumnIndex("placeID")));
                d.setPlaceName(cursor.getString(cursor.getColumnIndex("placeName")));
                d.setReviewDesc(cursor.getString(cursor.getColumnIndex("reviewDesc")));
                d.setReviewRate(cursor.getString(cursor.getColumnIndex("reviewRate")));
                d.setUserID(cursor.getString(cursor.getColumnIndex("userID")));
                d.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
                d.setUserEmail(cursor.getString(cursor.getColumnIndex("userEmail")));
                d.setMarkerColor(cursor.getString(cursor.getColumnIndex("markerColor")));
                d.setDate_added(cursor.getString(cursor.getColumnIndex("date_added")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    // GET REVIEWS BY GROUP
    public List<Review> getReviewsByGroup() {
        List<Review> plist = new ArrayList<>();
        String selectQuery = "SELECT * FROM reviews WHERE reviewDesc <> '' GROUP BY placeID ORDER BY date_added DESC";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Review d = new Review();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setPlaceID(cursor.getString(cursor.getColumnIndex("placeID")));
                d.setPlaceName(cursor.getString(cursor.getColumnIndex("placeName")));
                d.setReviewDesc(cursor.getString(cursor.getColumnIndex("reviewDesc")));
                d.setReviewRate(cursor.getString(cursor.getColumnIndex("reviewRate")));
                d.setUserID(cursor.getString(cursor.getColumnIndex("userID")));
                d.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
                d.setUserEmail(cursor.getString(cursor.getColumnIndex("userEmail")));
                d.setMarkerColor(cursor.getString(cursor.getColumnIndex("markerColor")));
                d.setDate_added(cursor.getString(cursor.getColumnIndex("date_added")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    // GET REVIEWS BY PLACE ID
    public List<Review> getReviewsByPlaceID(String placeID) {
        List<Review> plist = new ArrayList<>();
        String selectQuery = "SELECT * FROM reviews WHERE placeID = '" + placeID + "' ORDER BY date_added DESC";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Review d = new Review();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setPlaceID(cursor.getString(cursor.getColumnIndex("placeID")));
                d.setPlaceName(cursor.getString(cursor.getColumnIndex("placeName")));
                d.setReviewDesc(cursor.getString(cursor.getColumnIndex("reviewDesc")));
                d.setReviewRate(cursor.getString(cursor.getColumnIndex("reviewRate")));
                d.setUserID(cursor.getString(cursor.getColumnIndex("userID")));
                d.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
                d.setUserEmail(cursor.getString(cursor.getColumnIndex("userEmail")));
                d.setMarkerColor(cursor.getString(cursor.getColumnIndex("markerColor")));
                d.setDate_added(cursor.getString(cursor.getColumnIndex("date_added")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    // GET REVIEWS BY USER ID
    public List<Review> getHistory(String userID) {
        List<Review> plist = new ArrayList<>();
        String selectQuery = "SELECT * FROM reviews WHERE userID = '" + userID + "' ORDER BY date_added DESC";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Review d = new Review();
                d.setId(cursor.getString(cursor.getColumnIndex("id")));
                d.setPlaceID(cursor.getString(cursor.getColumnIndex("placeID")));
                d.setPlaceName(cursor.getString(cursor.getColumnIndex("placeName")));
                d.setReviewDesc(cursor.getString(cursor.getColumnIndex("reviewDesc")));
                d.setReviewRate(cursor.getString(cursor.getColumnIndex("reviewRate")));
                d.setUserID(cursor.getString(cursor.getColumnIndex("userID")));
                d.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
                d.setUserEmail(cursor.getString(cursor.getColumnIndex("userEmail")));
                d.setMarkerColor(cursor.getString(cursor.getColumnIndex("markerColor")));
                d.setDate_added(cursor.getString(cursor.getColumnIndex("date_added")));
                plist.add(d);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return plist;
    }

    public String getSettings(String code){
        String val = "";
        SQLiteDatabase dbW = this.getWritableDatabase();
        Cursor cursor = dbW.rawQuery("SELECT * FROM itr_settings WHERE code ='"+code+"'", null);
        if (cursor.moveToFirst()) {
            do {
                val = cursor.getString(cursor.getColumnIndex("value"));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return val;
    }

    // GET DASH
    public String getDash(String code){
        String val = "0";
        SQLiteDatabase dbW = this.getWritableDatabase();
        Cursor cursor = dbW.rawQuery("SELECT * FROM itr_dash WHERE code ='"+code+"'", null);
        if (cursor.moveToFirst()) {
            do {
                val = cursor.getString(cursor.getColumnIndex("value"));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return val;
    }

}