package com.uk.nationaltrustviewer.classes.review;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.activity.ReviewDetalis;
import com.uk.nationaltrustviewer.activity.StreetView;
import com.uk.nationaltrustviewer.config.AppConfig;
import com.uk.nationaltrustviewer.interfaces.ItemClickListener;

import java.util.List;

public class ReviewDetailsAdapter extends RecyclerView.Adapter<ReviewDetailsAdapter.MyViewHolder>{

    public List<Review> data;
    private Context context;
    private List<Review> filterList;
    private ReviewFilter filter;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView placeName, content, dateAdded;
        public RatingBar rating;

        public MyViewHolder(View view) {
            super(view);
            placeName = view.findViewById(R.id.placeName);
            content = view.findViewById(R.id.content);
            dateAdded = view.findViewById(R.id.dateAdded);
            rating = view.findViewById(R.id.ratingBar);
        }
    }

    public ReviewDetailsAdapter(Context context, List<Review> data) {
        this.data = data;
        this.context = context;
        this.filterList = data;
    }

    @Override
    @NonNull
    public MyViewHolder  onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout. template_review, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        Review d = data.get(position);
        holder.placeName.setText(d.getUserName());
        holder.content.setText(d.getReviewDesc());
        holder.dateAdded.setText(d.getDate_added());
        float rate = Float.parseFloat(d.getReviewRate());
        holder.rating.setRating(rate);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

}
