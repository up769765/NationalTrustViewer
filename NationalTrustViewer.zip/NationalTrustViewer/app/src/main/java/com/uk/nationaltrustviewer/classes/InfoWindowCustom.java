package com.uk.nationaltrustviewer.classes;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.uk.nationaltrustviewer.R;
import com.uk.nationaltrustviewer.activity.WriteReview;

public class InfoWindowCustom implements GoogleMap.InfoWindowAdapter {
    private Context context;
    private LayoutInflater inflater;

    private OnInfoWindowElemTouchListener infoButtonListener;

    public InfoWindowCustom(Context context) {
        this.context = context;
    }
    @Override
    public View getInfoContents(Marker marker) {
        return null;
    }
    @Override
    public View getInfoWindow(final Marker marker) {
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.map_info_window, null);
        TextView title = v.findViewById(R.id.title);
        RatingBar ratingBar = v.findViewById(R.id.ratingBar);
        Button write = v.findViewById(R.id.buttonWrite);
        title.setText(marker.getTitle());

        /*infoButtonListener = new OnInfoWindowElemTouchListener(save,
                context.getDrawable(R.drawable.button_dark_normal),
                context.getDrawable(R.drawable.button_dark_pressed)
        ) {
            @Override
            protected void onClickConfirmed(View v, Marker marker) {
                Log.d("CLICKED", "BUTTON SAVE CLICKED");
            }
        };
        save.setOnTouchListener(infoButtonListener);

        infoButtonListener = new OnInfoWindowElemTouchListener(write,
                context.getDrawable(R.drawable.button_dark_normal),
                context.getDrawable(R.drawable.button_dark_pressed)
        ) {
            @Override
            protected void onClickConfirmed(View v, Marker marker) {
                Log.d("CLICKED", "BUTTON WRITE CLICKED");
            }
        };
        write.setOnTouchListener(infoButtonListener);
*/

        /*write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, WriteReview.class);
                intent.putExtra("placeID", marker.getSnippet());
                intent.putExtra("placeName", marker.getTitle());
                context.startActivity(intent);
            }
        });*/

        /*save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, WriteReview.class);
                intent.putExtra("placeID", marker.getSnippet());
                intent.putExtra("placeName", marker.getTitle());
                context.startActivity(intent);
            }
        });*/



        return v;
    }
}